# Shopping EasyPAY

## Descrição

Plugin de Pagamento Shopping EasyPAY para Woocommerce, com: PIX, Boleto e Cartão de crédito

## Instalação

1. Faça o download do arquivo zip do plugin.
2. Acesse o painel de administração do seu site WordPress.
3. Vá para "Plugins" > "Adicionar Novo".
4. Clique no botão "Upload Plugin" e selecione o arquivo zip que você baixou.
5. Após o upload, clique em "Ativar Plugin".

## Configuração

1. Após ativar o plugin, vá para "Woocommerce" > "Pagamento" > "EasyPAY" no painel de administração.
2. Configure as opções conforme necessário e clique em "Salvar Alterações".

## Requisitos

- WordPress versão 6.5.2 ou superior.

## Suporte

Se você tiver alguma dúvida ou precisar de suporte, entre em contato conosco em [consultive@consultivesolucoes.com.br](mailto:consultive@consultivesolucoes.com.br) ou visite nossa página de suporte em [https://consultivesolucoes.com.br/contact/](https://consultivesolucoes.com.br/contact/).

## Contribuições

Por enquanto, repositório fechado para contribuições

## Licença

Este plugin é licenciado sob a Licença MIT. Consulte o arquivo [LICENSE](LICENSE) para obter detalhes.
