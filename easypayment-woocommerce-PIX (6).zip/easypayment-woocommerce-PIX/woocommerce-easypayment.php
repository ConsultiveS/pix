<?php
/**
 * Plugin Name:          Shopping EasyPAY para Woocommerce Credit, Billet and PIX
 * Plugin URI:           https://github.com/consultive/easypayment-woocommerce
 * Description:          Gateway de pagamentos Shopping EasyPAY para Woocommerce with Credit, Billet and PIX.
 * Author:               DanSP
 * Author URI:           https://t.me/dansp89
 * Version:              11.1.0
 * License:              GPLv3 or later
 * Text Domain:          woocommerce-easypayment
 * Domain Path:          /languages
 * WC requires at least: 8.0
 * WC tested up to:      8.7.0
 * Requires at least:    6.5.2
 * Requires PHP:         7.6
 */

defined('ABSPATH') || exit;

// Plugin constants.
define('WC_EASYPAYMENT_PLUGIN_FILE', __FILE__);
define('WC_EASYPAYMENT_PLUGIN_PATH', plugin_dir_path(__FILE__));    //PATH do Plugin
define('WC_EASYPAYMENT_PLUGIN_URL', plugin_dir_url(__FILE__));      //URL do Plugin

define('WC_EASYPAYMENT_URL_SANDBOX', 'https://sandboxeasypayment.pagtech.me/api/v1');
define('WC_EASYPAYMENT_URL_PRODUCTION', 'https://sistema.shoppingeasypay.com.br/api/v1');

// sistema.shoppingeasypay.com.br
if (!function_exists('get_plugin_data'))
    require_once (ABSPATH . 'wp-admin/includes/plugin.php');
$dsp_dashboard_info = get_plugin_data(WC_EASYPAYMENT_PLUGIN_PATH . "woocommerce-easypayment.php", false, true);
define('WC_EASYPAYMENT_VERSION', $dsp_dashboard_info['Version']);
define('WC_EAYSPAYMENT_TEXTDOMAIN', $dsp_dashboard_info['TextDomain']);
// echo "<pre>";
// var_dump($dsp_dashboard_info);
// var_dump(WC_EAYSPAYMENT_TEXTDOMAIN);
// echo "</pre>";
// die();
//Settins Cartão de crédito
define('WC_EASYPAYMENT_CARTAO_CREDITO_LIMITE', date("d/m/Y", strtotime('+3 days')));
define('WC_EASYPAYMENT_CARTAO_CREDITO_MAX_PARCELA', 12); //Parcelas máximas em X
define('WC_EASYPAYMENT_CARTAO_CREDITO_PRECO_MINIMO', 5); //Preço mínimo de cada parcela
define('WC_EASYPAYMENT_CARTAO_CREDITO_TAXA_FIXA', 0.47); //Taxa fixa por transação

$ratesEasypayment = [
    1 => 0,
    2 => 8.19,
    3 => 11.321,
    4 => 13.728,
    5 => 16.645,
    6 => 19.292,
    7 => 22.052,
    8 => 24.952,
    9 => 28.322,
    10 => 31.7,
    11 => 34.893,
    12 => 38.636
];

define('WC_EASYPAYMENT_DEFAULT_RATES', $ratesEasypayment);

$whitelist_easypayment_domain = ['127.0.0.1', "::1"]; //Domains allow whitelist to webhook POST

//Settings Boleto
define('WC_EASYPAYMENT_BOLETO_TAXA_FIXA', 3.49); //Taxa fixa do boleto

//Settings Carnê
define('WC_EASYPAYMENT_CARNE_LIMITE', date("Y-m-d", strtotime('+3 days'))); //Limite para parar a primeira parcela do carnê
define('WC_EASYPAYMENT_CARNE_MODE', 'split_price'); // Modos: split_price|total_price, consulte: https://sistema.shoppingeasypay.com.br/reference/criando-um-carne-de-boletos/
define('WC_EASYPAYMENT_CARNE_MAX_PARCELA', 12); //Parcelas máximas do Carnê
define('WC_EASYPAYMENT_CARNE_PRECO_MINIMO', 5); //Preço mínimo de cada parcela do carnê

define('WC_EASYPAYMENT_STATUS_FAILED', 'failed');
define('WC_EASYPAYMENT_STATUS_REFOUND', 'refound');
define('WC_EASYPAYMENT_STATUS_COMPLETED', 'completed');
define('WC_EASYPAYMENT_STATUS_WAITING', 'on-hold');

if (!class_exists('WC_Easypayment')) {
    include_once dirname(__FILE__) . '/includes/class-wc-easypayment.php';
    add_action('plugins_loaded', array('WC_EasyPayment', 'init'));

    add_action('init', function () {
        global $whitelist_easypayment_domain;

        $easypayment_url_dev = (Object) parse_url(WC_EASYPAYMENT_URL_SANDBOX);
        $easypayment_url_prod = (Object) parse_url(WC_EASYPAYMENT_URL_PRODUCTION);

        array_push($whitelist_easypayment_domain, $easypayment_url_dev->host);
        array_push($whitelist_easypayment_domain, $easypayment_url_prod->host);

        require WC_EASYPAYMENT_PLUGIN_PATH . 'includes/functions.php';
    });
}

add_action('wp_head', function () { ?>
    <script>
        const DSP_MSG_ACCEPT_CARD = '<?php _e('Card type accepted for this transaction.', 'woocommerce-easypayment') ?>';
        const DSP_MSG_NOT_ACCEPT_CARD = '<?php _e('Card type NOT accepted for this transaction', 'woocommerce-easypayment') ?>';
    </script>
    <?php
});

