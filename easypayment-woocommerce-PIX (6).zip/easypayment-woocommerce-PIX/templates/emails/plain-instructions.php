<?php
/**
 * Plain email instructions.
 *
 * @author  dansp89
 * @package WooCommerce_EasyPayment/Templates
 * @version 2.7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

_e( 'Payment', 'woocommerce-easypayment' );

echo "\n\n";

if ( 2 == $type ) {

	_e( 'Please use the link below to view your Banking Ticket, you can print and pay in your internet banking or in a lottery retailer:', 'woocommerce-easypayment' );

	echo "\n";

	echo esc_url( $link );

	echo "\n";

	_e( 'After we receive the ticket payment confirmation, your order will be processed.', 'woocommerce-easypayment' );

} elseif ( 3 == $type ) {

	_e( 'Please use the link below to make the payment in your bankline:', 'woocommerce-easypayment' );

	echo "\n";

	echo esc_url( $link );

	echo "\n";

	_e( 'After we receive the confirmation from the bank, your order will be processed.', 'woocommerce-easypayment' );

} else {

	echo sprintf( __( 'You just made the payment in %s using the %s.', 'woocommerce-easypayment' ), $installments . 'x', $method );

	echo "\n";

	_e( 'As soon as the credit card operator confirm the payment, your order will be processed.', 'woocommerce-easypayment' );

}

echo "\n\n****************************************************\n\n";
