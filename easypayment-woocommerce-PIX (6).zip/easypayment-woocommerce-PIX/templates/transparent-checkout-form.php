<?php
/**
 * Transparent checkout form.
 *
 * @author  DanSP
 * @package WooCommerce_EasyPayment/Templates
 * @version 2.12.5
 * @file ../includes/class-wc-easypayment-gateway.php
 * function payment_fields()  que retorna os valores
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

$arr_methods = array(
    'credit_card' => $easypayment_credit_card,
    'boleto' => $easypayment_boleto,
    'carne' => "no", //$easypayment_carne,
    'pix' => $easypayment_pix,
    'subscription' => "no", //$easypayment_subscription
);

$arr_methods_translate = array(
    'credit_card' => __("Credit Card", "woocommerce-easypayment"),
    'boleto' => __("Billet", "woocommerce-easypayment"),
    'carne' => __("Slip", "woocommerce-easypayment"),
    'pix' => __("PIX", "woocommerce-easypayment"),
    'subscription' => __("Subscription", "woocommerce-easypayment")
);

$o = 0;
$nav_html = '';
foreach ($arr_methods as $chave => $valor) {
    if ($valor == 'yes') {
        $method2process[$chave] = $valor;

        $actived = $o == 0 ? 'active' : '';
        $aria_selected = $o == 0 ? 'true' : 'false';
        $checked = $o == 0 ? 'checked="checked"' : '';
        $method_sluged = str_replace('_de_', '_', str_replace('-', '_', sanitize_title($chave)));
        $method_sluged_arr[] = $method_sluged;

        $nav_html .= "
            <div class='mb-5 nav-link $actived' data-bs-toggle='tab' data-named='$method_sluged' data-bs-target='#nav-$method_sluged' type='button' role='tab' aria-controls='nav-$method_sluged' aria-selected='$aria_selected'>
                <input type='radio' name='easypayment_method' value='$method_sluged' id='nav-$method_sluged-tab' class='d-none' $checked>
                <label for='nav-$method_sluged-tab'>" . $arr_methods_translate[$chave] . "</label>
            </div>";
        $o++;
    }
}
$activeNow = [];
if (count($arr_methods) > 0) {

    foreach ($arr_methods as $ke => $va) {
        if ($va == "yes") {
            $activeNow[$ke] = true;
            break;
        }
    }
}
?>

<fieldset id="easypayment-payment-form"
    class="<?php echo 'storefront' === basename(get_template_directory()) ? 'woocommerce-easypayment-form-storefront' : ''; ?>"
    data-cart_total="<?php echo esc_attr(number_format($cart_total, 2, '.', '')); ?>">
    <!-- Tabs Begin -->
    <input type="hidden" name="easypayment_cart_total"
        value="<?php echo esc_attr(number_format($cart_total, 2, '.', '')); ?>" readonly="readonly" />
    <input type="hidden" name="easypayment_method" id="easypayment_method" value="<?php echo $method_sluged_arr[0]; ?>"
        readonly="readonly" />
    <nav>
        <div class="nav nav-tabs" id="nav-tab" role="tablist">
            <?php echo $nav_html; ?>
        </div>
    </nav>

    <div class="tab-content" id="nav-tabContent">
        <?php
        if ($easypayment_credit_card == 'yes'):
            ?>
            <!-- START - CARTÃO -->
            <div class="tab-pane <?php _e(isset($activeNow['credit_card']) && $activeNow['credit_card'] == true ? "show active" : "") ?>"
                id="nav-credit_card" role="tabpanel" aria-labelledby="nav-credit_card-tab">
                <div class="container cartao_plastico preload">
                    <div class="row mb-4">
                        <div class="col">
                            <div class="form-floating mb-6">
                                <input type="text" class="form-control" name="cartao_credito[holder_name]"
                                    id="cartao_credito[holder_name]" maxlength="20">
                                <label
                                    for="cartao_credito[holder_name]"><?php _e("Holder name", "woocommerce-easypayment") ?></label>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-floating mb-6">
                                <input type="text" class="form-control format-cpf" name="cartao_credito[holder_cpf_cnpj]"
                                    id="cartao_credito[holder_cpf_cnpj]">
                                <label
                                    for="cartao_credito[holder_cpf_cnpj]"><?php _e("CPF", "woocommerce-easypayment") ?></label>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col">
                            <div class="form-floating mb-6">
                                <input type="text" class="form-control format-credit-card"
                                    name="cartao_credito[card_number]" id="cartao_credito[card_number]" maxlength="19"
                                    pattern="[0-9]*" inputmode="numeric">
                                <svg id="ccicon" class="ccicon" width="750" height="471" viewBox="0 0 750 471" version="1.1"
                                    xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"></svg>
                                <?php
                                if ((isset($card_demo) && $card_demo == 'yes') && current_user_can('manage_options')) {
                                    echo '<label for="cartao_credito[card_number]">' . __("Card number", "woocommerce-easypayment") . '</label><span id="generatecard">' . __("Random test", "woocommerce-easypayment") . '</span>';
                                }
                                ?>
                                <label for="card_number"><?php _e("Card number", "woocommerce-easypayment") ?></label>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col">
                            <div class="form-floating mb-6">
                                <input type="text" class="form-control format-cvv" name="cartao_credito[cvv]"
                                    id="cartao_credito[cvv]" pattern="[0-9]*" inputmode="numeric">
                                <label for="cartao_credito[cvv]"><?php _e("CVV", "woocommerce-easypayment") ?></label>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-floating mb-6">
                                <input type="text" class="form-control format-expiration" name="cartao_credito[expiration]"
                                    id="cartao_credito[expiration]" pattern="[0-9]*" inputmode="numeric">
                                <label for="cartao_credito[expiration]"><?php _e("Expiration", "woocommerce-easypayment") ?>
                                    (mm/yy)</label>
                            </div>
                        </div>
                    </div>
                    <?php
                    $totalIncart = number_format($cart_total, 2, '.', '');
                    $valorMinimo = WC_EASYPAYMENT_CARTAO_CREDITO_PRECO_MINIMO;
                    $valorMaximo = WC_EASYPAYMENT_CARTAO_CREDITO_MAX_PARCELA;
                    $taxaFixa = WC_EASYPAYMENT_CARTAO_CREDITO_TAXA_FIXA;
                    $ratesEasyPayment = WC_EASYPAYMENT_DEFAULT_RATES;

                    $aVista = wc_price(number_format($cart_total, 2, '.', ''));
                    $outerParcelas = "<option value='1' selected>" . sprintf(__("In cash by %s", "woocommerce-easypayment"), $aVista) . "</option>";
                    foreach ($ratesEasyPayment as $rateInstallment => $rateInstallmentValue) {
                        $priceFloat = ((($cart_total / 100) * $rateInstallmentValue) + $cart_total) / $rateInstallment;
                        $price = wc_price(number_format($priceFloat, 2, '.', ''));

                        if ($priceFloat <= $valorMinimo)
                            break;

                        if ($rateInstallmentValue > $valorMinimo) {
                            $outerParcelas .= "<option value='$rateInstallment'>" . sprintf(__("%sx of %s", "woocommerce-easypayment"), $rateInstallment, $price) . "</option>";
                        }
                    }

                    ?>
                    <div class="row mb-4">
                        <div class="col">
                            <div class="form-floating">
                                <select class="form-select" name="cartao_credito[number_installments]"
                                    id="cartao_credito[number_installments]" aria-label="Floating label select">
                                    <?php echo $outerParcelas; ?>
                                </select>
                                <label
                                    for="cartao_credito[number_installments]"><?php _e("Installments", "woocommerce-easypayment") ?></label>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <!-- END - CARTÃO -->
            <?php
        endif;

        if ($easypayment_boleto == 'yes'): ?>
            <!-- START - BOLETO -->
            <div class="tab-pane <?php _e(isset($activeNow['boleto']) && $activeNow['boleto'] == true ? "show active" : "") ?>"
                id="nav-boleto" role="tabpanel" aria-labelledby="nav-boleto-tab">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="easypaymentBoletoMaster"></div>
                        </div>
                        <div class="col-12 easypayment_message_boleto">
                            <?php
                            _e(sprintf(__("* After clicking on \"Proceed to payment\" you will have access to the bank slip that you can print and pay on your internet banking or in a lottery, the value is <b>%s</b>", "wocommerce-easypayment"), wc_price(number_format($cart_total, 2, '.', ''))));
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END - BOLETO -->
            <?php
        endif;

        if ($easypayment_carne == 'yes'):
            ?>
            <!-- START - CARNÊ -->
            <div class="tab-pane" id="nav-carne" role="tabpanel" aria-labelledby="nav-carne-tab">
                <div class="container">
                    <?php
                    $totalIncartCarne = number_format($cart_total, 2, '.', '');
                    $valorMinimo = WC_EASYPAYMENT_CARNE_PRECO_MINIMO;
                    $valorMaximo = WC_EASYPAYMENT_CARNE_MAX_PARCELA;

                    for ($c = 1; $c < $totalIncartCarne; $c++) {
                        $val_installmentCarne = $totalIncartCarne / $c;
                        if ($val_installmentCarne >= $valorMinimo) {
                            $init_installmentsCarne[] = $val_installmentCarne;
                        }
                    }
                    $outerParcelasCarne = '';
                    $aVistaCarne = wc_price(number_format($cart_total, 2, '.', ''));
                    if (isset($init_installmentsCarne) && count($init_installmentsCarne) > 0) {
                        $cpp = 0;
                        $outerParcelasCarne .= "<option value='' selected>" . __("-- Select a parcel --", "woocommerce-easypayment") . "</option>";
                        foreach ($init_installmentsCarne as $valor_parcelas_carne) {
                            $cpp++;
                            $parcelado_carne = wc_price(number_format($valor_parcelas_carne + $taxaFixa, 2, '.', ''));
                            if ($valor_parcelas_carne >= $valorMinimo) {
                                if ($cpp == 1) {
                                    //$outerParcelasCarne .= "<option value='$cpp'>A vista por $aVistaCarne</option>";
                                } else {
                                    $outerParcelasCarne .= "<option value='$cpp'>" . sprintf(__("Pay in up to %s installments of %s", "woocommerce-easypayment"), $cpp, $parcelado_carne) . "</option>";
                                }
                                if ($valorMaximo <= $cpp)
                                    break;
                            }
                        }
                    } else {
                        $outerParcelasCarne .= "<option value='1' selected>" . sprintf(__("Pay the amount of %s upfront", "woocommerce-easypayment"), $aVistaCarne) . "Pague o valor de sss a vista</option>";
                    }
                    ?>
                    <div class="row mb-4">
                        <div class="col">
                            <?php
                            _e(sprintf("Payment in the carnê you can spread your purchases directly on the boleto in up to 12 interest-free installments! the first installment will be on the day %s", "woocommerce-easypayment"), date("d/m/Y", strtotime(WC_EASYPAYMENT_CARNE_LIMITE)));
                            ?>
                        </div>
                    </div>
                    <div class="row mb-4">
                        <div class="col">
                            <div class="form-floating">
                                <select class="form-select" name="carne[number_installments]"
                                    id="carne[number_installments]" aria-label="Floating label select">
                                    <?php echo $outerParcelasCarne; ?>
                                </select>
                                <label
                                    for="carne[number_installments]"><?php _e("Installments", "woocommerce-easypayment") ?></label>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!-- END - CARNÊ -->
            <?php
        endif;

        if ($easypayment_pix == 'yes'): ?>
            <!-- START - PIX -->
            <div class="tab-pane" id="nav-pix" role="tabpanel" aria-labelledby="nav-pix-tab">
                <div class="col-12">
                    <div class="easypaymentPixMaster"></div>
                </div>
                <?php _e("Pay with PIX, a Brazilian payment method, the best payment system in the world!", "woocommerce-easypayment") ?>
            </div>
            <!-- END - PIX -->
            <?php
        endif;

        if ($easypayment_subscription == 'yes'):
            ?>
            <!-- START - SUBSCRIPTION -->
            <div class="tab-pane" id="nav-subscription" role="tabpanel" aria-labelledby="nav-subscription-tab">
                <?php _e("Subscription", "woocommerce-easypayment") ?>
            </div>
            <!-- START - SUBSCRIPTION -->
            <?php
        endif;
        ?>
    </div>
    <!-- Tabs End -->
</fieldset>