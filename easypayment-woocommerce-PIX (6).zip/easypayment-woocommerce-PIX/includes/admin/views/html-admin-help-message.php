<?php
/**
 * Admin help message.
 *
 * @package WooCommerce_EasyPayment/Admin/Settings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}