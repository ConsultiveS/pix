<?php
/**
 * Gateway class
 *
 * @package WooCommerce_EasyPayment/Classes/Gateway
 * @source SIMPLE HTML DOM <https://github.com/voku/simple_html_dom>
 * @version 2.13.0
 */

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Gateway.
 */
class WC_EasyPayment_Gateway extends WC_Payment_Gateway
{

	public $form_fields;
	/**
	 * Constructor for the gateway.
	 */
	public function __construct()
	{

		$this->siteurl = site_url();
		$this->id = 'easypayment';
		$this->paymentLabel = ucfirst($this->id);
		// $this->icon = apply_filters('woocommerce_easypayment_icon', plugins_url('assets/images/logo-shopping-easy-pay.jpg', plugin_dir_path(__FILE__)));
		$this->method_title = __($this->paymentLabel, 'woocommerce-easypayment');
		$this->method_description = sprintf(__('Accept payments by credit card, bank debit or bank slip using %s', 'woocommerce-easypayment'), $this->paymentLabel);
		$this->order_button_text = __('Proceed to payment', 'woocommerce-easypayment');

		// Load the form fields.
		$this->init_form_fields();

		// Load the settings.
		$this->init_settings();

		// Define user set variables.
		$this->title = $this->get_option('title');
		$this->description = $this->get_option('description');
		//$this->email                      = $this->get_option( 'email' );
		$this->token = $this->get_option('token');
		//$this->sandbox_email              = $this->get_option( 'sandbox_email' );
		$this->sandbox_token = $this->get_option('sandbox_token');
		$this->method = $this->get_option('method', 'direct');
		$this->easypayment_cartao_credito = $this->get_option('easypayment_cartao_credito', 'yes');
		$this->easypayment_boleto = $this->get_option('easypayment_boleto', 'yes');
		$this->easypayment_assinatura = $this->get_option('easypayment_assinatura', 'no');
		$this->easypayment_pix = $this->get_option('easypayment_pix', 'no');
		$this->easypayment_carne = $this->get_option('easypayment_carne', 'no');
		$this->tc_ticket_message = $this->get_option('tc_ticket_message', 'yes');
		$this->send_only_total = $this->get_option('send_only_total', 'no');
		$this->invoice_prefix = $this->get_option('invoice_prefix', 'WC-');
		$this->sandbox = $this->get_option('sandbox', 'no');
		$this->debug = $this->get_option('debug');
		$this->payment_type = $this->get_option("payment_type");

		// max_installments será obrigatório se $this->payment_type for algum item do array
		$this->payment_type_request = ["installments_customer", "interest_free"];


		$this->send_erros_by_email = $this->get_option('send_erros_by_email'); // 'no'||'yes'
		$this->send_email_erros = $this->get_option('send_email_erros');  //Email list

		$this->sendErrorsEmailList = explode(";", $this->send_email_erros); //Array with email list to send erros

		$paymentNamed = ucfirst($this->id);
		$paymentNamed = "<b>$paymentNamed</b>";
		$this->status_easypayment = array(
			'pending' => array(
				'label' => __('Pending', 'woocommerce-easypayment'), //Rótulo para exibir na lista de produtos ou o pedido
				'wc_status' => 'pending', //Status no Woocommerce
				'wc_create' => false,   //Se será criado o status o pedido
				'wc_update_notes' => __("$paymentNamed: The customer has not yet made the payment", 'woocommerce-easypayment'), //Nota para a loja
				'wc_update_status' => __("$paymentNamed: Your order #%s is pending payment", 'woocommerce-easypayment'), //Nota para o cliente
				'wc_stock_update' => 'decrease',      // increase|decrease adicionar ou remover do estoque
				'wc_send_email' => true             // Enviar email sobre o pedido?
			),
			'in_analysis' => array(
				'label' => __('Under analysis', 'woocommerce-easypayment'),
				'wc_status' => 'processing',
				'wc_create' => false,
				'wc_update_notes' => __("$paymentNamed: Payment is currently under review", 'woocommerce-easypayment'),
				'wc_update_status' => __("$paymentNamed: Your order #%s is currently under review/processing", 'woocommerce-easypayment'),
				'wc_stock_update' => 'decrease',
				'wc_send_email' => true
			),
			'succeeded' => array(
				'label' => __('Approved', 'woocommerce-easypayment'),
				'wc_status' => 'completed',
				'wc_create' => false,
				'wc_update_notes' => __("$paymentNamed: Payment made successfully", 'woocommerce-easypayment'),
				'wc_update_status' => __("$paymentNamed: Your payment for order #%s was successful", 'woocommerce-easypayment'),
				'wc_stock_update' => 'decrease',
				'wc_send_email' => true
			),
			'failed' => array(
				'label' => __('Failed', 'woocommerce-easypayment'),
				'wc_status' => 'failed',
				'wc_create' => false,
				'wc_update_notes' => __("$paymentNamed: Payment failure", 'woocommerce-easypayment'),
				'wc_update_status' => __("$paymentNamed: Payment failed, please contact support", 'woocommerce-easypayment'),
				'wc_stock_update' => 'increase',
				'wc_send_email' => true
			),
			'reversed' => array(
				'label' => __('Reversed', 'woocommerce-easypayment'),
				'wc_status' => 'refunded',
				'wc_create' => true,
				'wc_update_notes' => sprintf(__("$paymentNamed: Chargeback request in progress, check the progress on the %s dashboard and update your order here if necessary", 'woocommerce-easypayment'), $paymentNamed),
				'wc_update_status' => __("$paymentNamed: A chargeback request has been opened for order #%s, follow the progress in your email or on the website.", 'woocommerce-easypayment'),
				'wc_stock_update' => 'increase',
				'wc_send_email' => true
			),
			'canceled' => array(
				'label' => __('Canceled', 'woocommerce-easypayment'),
				'wc_status' => 'cancelled',
				'wc_create' => false,
				'wc_update_notes' => __("$paymentNamed: The order was canceled", 'woocommerce-easypayment'),
				'wc_update_status' => __("$paymentNamed: Your order #%s has been canceled", 'woocommerce-easypayment'),
				'wc_stock_update' => 'increase',
				'wc_send_email' => true
			),
			'refunded' => array(
				'label' => __('Refunded', 'woocommerce-easypayment'),
				'wc_status' => 'refunded',
				'wc_create' => false,
				'wc_update_notes' => __("$paymentNamed: Refund request made successfully, waiting for progress", 'woocommerce-easypayment'),
				'wc_stock_update' => 'increase',
				'wc_send_email' => true
			),
			'dispute' => array(
				'label' => __('In dispute', 'woocommerce-easypayment'),
				'wc_status' => 'dispute',
				'wc_create' => true,
				'wc_update_notes' => __("$paymentNamed: The order is in dispute", 'woocommerce-easypayment'),
				'wc_update_status' => __("$paymentNamed: Order #%s is in dispute.", 'woocommerce-easypayment'),
				'wc_stock_update' => 'increase',
				'wc_send_email' => true
			),
			'charged_back' => array(
				'label' => __('Chargeback', 'woocommerce-easypayment'),
				'wc_status' => 'charged_back',
				'wc_create' => true,
				'wc_update_notes' => __("$paymentNamed: Chargeback order", 'woocommerce-easypayment'),
				'wc_update_status' => __("$paymentNamed: The order is in chargeback, we are checking if everything is ok, don't worry", 'woocommerce-easypayment'),
				'wc_stock_update' => 'increase',
				'wc_send_email' => true
			)
		);

		$this->has_fields = $this->has_fields();
		$this->api = new WC_EasyPayment_API($this);

		// Adiciona ação para a função receipt_page() apenas uma vez
		if (!has_action('woocommerce_receipt_' . $this->id)) {
			add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'), 10, 1);
		}

		add_action('wc' . $this->id . '_ipn_request', array($this, 'update_order_status'), 10, 1);
		add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
		add_action('init', array($this, 'dsp_register_news_order_status'));
		add_filter('wc_order_statuses', array($this, 'dsp_add_to_order_statuses'));

		// Transparent checkout actions.
		if ('transparent' === $this->method) {
			add_action('woocommerce_thankyou_', array($this, 'thankyou_page'), 12, 1);
			add_action('woocommerce_email_after_order_table', array($this, 'email_instructions'), 10, 3);
			add_action('wp_enqueue_scripts', array($this, 'checkout_scripts'), 52);
		}
	}

	/**
	 * Registrar novos Status para o Woocommerce
	 * Source: https://www.godaddy.com/garage/how-to-create-custom-woocommerce-order-status/
	 */
	public function dsp_register_news_order_status()
	{
		foreach ($this->status_easypayment as $key => $val) {
			register_post_status(
				"wc-$key",
				array(
					'label' => $val['label'],
					'public' => true,
					'exclude_from_search' => true,
					'show_in_admin_all_list' => true,
					'show_in_admin_status_list' => true,
					'label_count' => _n_noop("$key (%s)", $val['label'] . " (%s)")
				)
			);
		}
	}

	/**
	 * adicionará esse novo status de postagem personalizado à lista de status de pedidos disponíveis nas páginas "Pedidos" e "Editar pedidos" do WooCommerce
	 * Source: https://www.godaddy.com/garage/how-to-create-custom-woocommerce-order-status/
	 */
	public function dsp_add_to_order_statuses($order_statuses)
	{

		$new_order_statuses = array();

		//Obter lista existente de status
		foreach ($order_statuses as $key => $status) {
			$new_order_statuses[$key] = $status;
		}

		//Obter lista personalizada de status
		foreach ($this->status_easypayment as $key => $val) {
			if (isset($val['wc_create']) && $val['wc_create'] == true) {
				$key = sanitize_title($key);
				$new_order_statuses["wc-$key"] = $val['label'];
			}
		}
		// print_r('$new_order_statuses: ', $new_order_statuses);
		return $new_order_statuses;
	}

	/**
	 * Returns a bool that indicates if currency is amongst the supported ones.
	 *
	 * @return bool
	 */
	public function using_supported_currency()
	{
		return 'BRL' === get_woocommerce_currency();
	}

	/**
	 * Get email.
	 *
	 * @return string
	 */
	public function get_email()
	{
		return 'yes' === $this->sandbox ? $this->sandbox_email : $this->email;
	}

	/**
	 * Get token.
	 *
	 * @return string
	 */
	public function get_token()
	{
		// return 'yes' === $this->sandbox ? $this->sandbox_token : $this->token;
		return $this->token;
	}

	/**
	 * Returns a value indicating the the Gateway is available or not. It's called
	 * automatically by WooCommerce before allowing customers to use the gateway
	 * for payment.
	 *
	 * @return bool
	 */
	public function is_available()
	{
		// Test if is valid for use.
		//$available = 'yes' === $this->get_option( 'enabled' ) && '' !== $this->get_email() && '' !== $this->get_token() && $this->using_supported_currency();

		$available = 'yes' === $this->get_option('enabled') && '' !== $this->get_token() && $this->using_supported_currency();
		// var_dump('is_available: '.$available);
		if ('transparent' === $this->method) {
			// if ( 'transparent' === $this->method && ! class_exists( 'Extra_Checkout_Fields_For_Brazil' ) ) {
			$available = true;
		}

		return $available;
	}

	/**
	 * Has fields.
	 *
	 * @return bool
	 */
	public function has_fields()
	{
		return 'transparent' === $this->method;
	}

	/**
	 * Checkout scripts.
	 */
	public function checkout_scripts()
	{
		$suffix = '';
		if (is_checkout() && $this->is_available()) {
			wp_enqueue_style('easypayment-bootstrap', plugins_url('assets/css/frontend/bootstrap.min' . $suffix . '.css', plugin_dir_path(__FILE__)), array(), WC_EASYPAYMENT_VERSION);
			if (!get_query_var('order-received')) {
				$session_id = 'manual_session_ok';
				wp_enqueue_style('easypayment-checkout', plugins_url('assets/css/frontend/transparent-checkout' . $suffix . '.css', plugin_dir_path(__FILE__)), array(), WC_EASYPAYMENT_VERSION);

				wp_enqueue_script('jquery-mask', 'https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js', array('jquery'), '1.14.16', true);
				// wp_enqueue_script('easypayment-checkout', plugins_url('assets/js/frontend/transparent-checkout' . $suffix . '.js', plugin_dir_path(__FILE__)), array(), WC_EASYPAYMENT_VERSION, true);
				wp_enqueue_script('easypayment-checkout', plugins_url('assets/js/frontend/transparent-checkout.js', plugin_dir_path(__FILE__)), array(), WC_EASYPAYMENT_VERSION, true);
				// wp_enqueue_script('easypayment-bootstrap', plugins_url('assets/js/frontend/bootstrap.min' . $suffix . '.js', plugin_dir_path(__FILE__)), array(), WC_EASYPAYMENT_VERSION, false);
				// wp_enqueue_script('easypayment-bootstrap', plugins_url('assets/js/frontend/bootstrap.bundle.min' . $suffix . '.js', plugin_dir_path(__FILE__)), array(), WC_EASYPAYMENT_VERSION, false);


				wp_localize_script(
					'easypayment-checkout',
					'wc_easypayment_params',
					array(
						'session_id' => $session_id,
						'interest_free' => __('interest free', 'woocommerce-easypayment'),
						'invalid_card' => __('Invalid credit card number.', 'woocommerce-easypayment'),
						'invalid_expiry' => __('Invalid expiry date, please use the MM / YYYY date format.', 'woocommerce-easypayment'),
						'expired_date' => __('Please check the expiry date and use a valid format as MM / YYYY.', 'woocommerce-easypayment'),
						'general_error' => __('Unable to process the data from your credit card on the EasyPayment, please try again or contact us for assistance.', 'woocommerce-easypayment'),
						'empty_installments' => __('Select a number of installments.', 'woocommerce-easypayment'),
					)
				);
			}
		}
	}

	/**
	 * Get log.
	 *
	 * @return string
	 */
	protected function get_log_view()
	{
		if (defined('WC_VERSION') && version_compare(WC_VERSION, '2.2', '>=')) {
			return '<a href="' . esc_url(admin_url('admin.php?page=wc-status&tab=logs&log_file=' . esc_attr($this->id) . '-' . sanitize_file_name(wp_hash($this->id)) . '.log')) . '">' . __('System Status &gt; Logs', 'woocommerce-easypayment') . '</a>';
		}

		return '<code>woocommerce/logs/' . esc_attr($this->id) . '-' . sanitize_file_name(wp_hash($this->id)) . '.txt</code>';
	}

	/**
	 * Initialise Gateway Settings Form Fields.
	 */
	public function init_form_fields()
	{
		$this->form_fields = array(
			'enabled' => array(
				'title' => __('Habilitar desabilitar', 'woocommerce-easypayment'),
				'type' => 'checkbox',
				'label' => __('Enable ' . $this->id, 'woocommerce-easypayment'),
				'default' => 'yes',
			),
			'title' => array(
				'title' => __('Title', 'woocommerce-easypayment'),
				'type' => 'text',
				'description' => __('This controls the title the user sees during checkout.', 'woocommerce-easypayment'),
				'desc_tip' => true,
				'default' => __('EasyPayment', 'woocommerce-easypayment'),
			),
			'description' => array(
				'title' => __('Description', 'woocommerce-easypayment'),
				'type' => 'textarea',
				'description' => __('This controls the description the user sees during checkout', 'woocommerce-easypayment'),
				'default' => __('Pay by EasyPayment', 'woocommerce-easypayment'),
			),
			'integration' => array(
				'title' => __('Integration', 'woocommerce-easypayment'),
				'type' => 'title',
				'description' => '',
			),
			'method' => array(
				'title' => __('Integration method', 'woocommerce-easypayment'),
				'type' => 'select',
				'description' => __('Choose how the customer will interact with the EasyPayment. Redirect (Client goes to EasyPayment page) or Lightbox (Inside your store)', 'woocommerce-easypayment'),
				'desc_tip' => true,
				'default' => 'transparent',
				'class' => 'wc-enhanced-select',
				'options' => array(
					// 'redirect' => __('Redirect (default)', 'woocommerce-easypayment'),
					// 	'lightbox'    => __( 'Lightbox', 'woocommerce-easypayment' ),
					'transparent' => __('Transparent Checkout', 'woocommerce-easypayment'),
				),
			),
			'payment_type' => array(
				'title' => __('installments customer', 'woocommerce-easypayment'),
				'type' => 'select',
				'description' => __('Method by which payment will be processed. This option is only mandatory when the charge is being made via credit card', 'woocommerce-easypayment'),
				'desc_tip' => true,
				'default' => 'installments_customer',
				'class' => 'wc-enhanced-select',
				'options' => array(
					'installments_customer' => __('Installment with interest for the customer.', 'woocommerce-easypayment'),
					'interest_free' => __('Interest-free installments.', 'woocommerce-easypayment'),
				),
			),
			'sandbox' => array(
				'title' => __('EasyPAY Sandbox', 'woocommerce-easypayment'),
				'type' => 'checkbox',
				'label' => __('Habilitar EasyPAY Sandbox', 'woocommerce-easypayment'),
				'desc_tip' => true,
				'default' => 'no',
				'description' => __('EasyPAY Sandbox pode ser usado para testar os pagamentos.', 'woocommerce-easypayment'),
			),
			'token' => array(
				'title' => __('EasyPAY Token', 'woocommerce-easypayment'),
				'type' => 'password',
				/* translators: %s: link to EasyPAY settings */
				'description' => __(''),
				'default' => '',
			),
			'sandbox_token' => array(
				'title' => __('EasyPAY Sandbox Token', 'woocommerce-easypayment'),
				'type' => 'text',
				/* translators: %s: link to EasyPAY settings */
				'description' => __(''),
				'default' => '',
			),
			'title_easypayment_transacao' => array(
				'title' => __('TRANSAÇÃO'),
				'type' => 'title',
				'description' => '',
			),
			'easypayment_cartao_credito' => array(
				'title' => __('Credit card', 'woocommerce-easypayment'),
				'type' => 'checkbox',
				'label' => __("We offer partners the option of receiving payments by credit card, so it is the merchant who decides how many times the purchase can be paid in installments, and all other installment conditions.<br />Accepted flags: <b>Visa</ b>, <b>MasterCard</b>, <b>Hiper</b>, <b>Hipercard</b>, <b>Dinners Club</b>, <b>American Express</b> and <b>Link</b>.", 'woocommerce-easypayment'),
				'default' => 'yes',
			),
			'easypayment_boleto' => array(
				'title' => __('Billet', 'woocommerce-easypayment'),
				'type' => 'checkbox',
				'label' => __("Among the payment options, the platform has the option of payment via bank slip, a document that allows the order to be paid at any bank, lottery or via internet banking.<br />We use Banco Itaú and Banco do Brasil to issuance of tickets.", 'woocommerce-easypayment'),
				'default' => 'yes',
			),
			'easypayment_pix' => array(
				'title' => __('PIX', 'woocommerce-easypayment'),
				'type' => 'checkbox',
				'label' => __("Brazilian instant payment, the best payment system in the universe.", 'woocommerce-easypayment'),
				'default' => 'yes',
			),
			'behavior' => array(
				'title' => __('Integration Behavior', 'woocommerce-easypayment'),
				'type' => 'title',
				'description' => '',
			),
			'send_only_total' => array(
				'title' => __('Send only the order total', 'woocommerce-easypayment'),
				'type' => 'checkbox',
				'label' => __('If this option is enabled, it will only send the order total, not the list of items..', 'woocommerce-easypayment'),
				'default' => 'no',
			),
			'invoice_prefix' => array(
				'title' => __('Invoice prefix', 'woocommerce-easypayment'),
				'type' => 'text',
				'description' => __('Enter a prefix for your invoice numbers. If you use your EasyPAY account for multiple stores, please make sure that this prefix is not valid, as EasyPayment does not allow orders with the same invoice number.', 'woocommerce-easypayment'),
				'desc_tip' => true,
				'default' => 'WC-',
			),
			'testing' => array(
				'title' => __('Gateway tests', 'woocommerce-easypayment'),
				'type' => 'title',
				'description' => '',
			),
			'debug' => array(
				'title' => __('Error log', 'woocommerce-easypayment'),
				'type' => 'checkbox',
				'label' => __('Enable logs', 'woocommerce-easypayment'),
				'default' => 'no',
				/* translators: %s: log page link */
				'description' => sprintf(__('Log EasyPAY events such as API requests to %s', 'woocommerce-easypayment'), $this->get_log_view()),
			),
			'send_erros_by_email' => array(
				'title' => __('Send error log by email', 'woocommerce-easypayment'),
				'type' => 'checkbox',
				'label' => __('Enable/Disable', 'woocommerce-easypayment'),
				'default' => 'no',
				'description' => __('This will allow you to send checkout error logs to whomever you allow on the list when you have enabled this option.', 'woocommerce-easypayment'),
			),
			'send_email_erros' => array(
				'title' => __('Send errors by email', 'woocommerce-easypayment'),
				'type' => 'textarea',
				'label' => __('E-mail list', 'woocommerce-easypayment'),
				'placeholder' => 'developer@shoppingeasypay.com.br',
				'default' => 'developer@shoppingeasypay.com.br',
				'description' => __('<div id="emailList"></div>Add a list of emails separated by semicolons (;), these emails will receive in your email box an error report from the checkout, this option is valid only if you have enabled error logs. Only add an email list that you really need such as developers, managers and support for your website. Note that this option is not mandatory.', 'woocommerce-easypayment'),
			),
		);
	}

	/**
	 * Admin page.
	 */
	public function admin_options()
	{
		$suffix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_script('easypayment-admin', plugins_url('assets/js/admin/admin' . $suffix . '.js', plugin_dir_path(__FILE__)), array('jquery'), WC_EASYPAYMENT_VERSION, true);

		include dirname(__FILE__) . '/admin/views/html-admin-page.php';
	}

	/**
	 * Send email notification.
	 *
	 * @param string $subject Email subject.
	 * @param string $title   Email title.
	 * @param string $message Email message.
	 */
	protected function send_email($subject, $title, $message)
	{
		$mailer = WC()->mailer();

		$mailer->send(get_option('admin_email'), $subject, $mailer->wrap_message($title, $message));
	}

	/**
	 * Payment fields.
	 */
	public function payment_fields()
	{
		// echo "CAMPOS";
		wp_enqueue_script('wc-credit-card-form');

		$description = $this->get_description();
		if ($description) {
			echo wpautop(wptexturize($description)); // WPCS: XSS ok.
		}

		$cart_total = $this->get_order_total();
		if ('transparent' === $this->method) {
			wc_get_template(
				'transparent-checkout-form.php',
				array(
					'cart_total' => $cart_total,
					'easypayment_credit_card' => $this->easypayment_cartao_credito,
					'easypayment_boleto' => $this->easypayment_boleto,
					'easypayment_subscription' => $this->easypayment_assinatura,
					'easypayment_pix' => $this->easypayment_pix,
					'easypayment_carne' => $this->easypayment_carne,
					'tc_ticket_message' => $this->tc_ticket_message,
					'flag' => plugins_url('assets/images/brazilian-flag.png', plugin_dir_path(__FILE__)),
				),
				'woocommerce/easypayment/',
				WC_EasyPayment::get_templates_path()
			);
		} else if ('redirect' === $this->method) {
			echo "Irá ser redirecionado para a uma página externas";
		}
	}

	/**
	 * Criar ou atualizar um cliente, valores oriundos do $_POST do formulário do checkout e retorna o ID do cliennte
	 * @param array $data_post
	 * @return int 
	 */
	public function easypayment_cliente($data_post)
	{

		$fullname['first_name'] = isset($data_post['billing_first_name']) ? sanitize_text_field($data_post['billing_first_name']) : '';
		$fullname['last_name'] = isset($data_post['billing_last_name']) ? sanitize_text_field($data_post['billing_last_name']) : '';
		$full_name = implode(' ', $fullname);
		$number_phone = get_only_numbers($data_post['billing_phone']);

		$body_params["cc_email"] = isset($data_post['billing_email']) ? sanitize_email($data_post['billing_email']) : null; // Optional
		$body_params["city"] = isset($data_post['billing_city']) ? sanitize_text_field($data_post['billing_city']) : '';
		$body_params["complement"] = isset($data_post['billing_address_2']) ? sanitize_text_field($data_post['billing_address_2']) : '';
		$body_params["email"] = isset($data_post['billing_email']) ? sanitize_email($data_post['billing_email']) : '';
		$body_params["full_name"] = $full_name;       // Required 
		$body_params["neighborhood"] = isset($data_post['billing_neighborhood']) ? sanitize_text_field($data_post['billing_neighborhood']) : '';
		$body_params["notes"] = isset($data_post['order_comments']) ? sanitize_text_field($data_post['order_comments']) : null; // Optional
		$body_params["number"] = isset($data_post['billing_number']) ? sanitize_text_field($data_post['billing_number']) : '';
		$body_params["phone_number"] = isset($data_post['billing_phone']) ? sanitize_text_field(mask($number_phone, '##-#####-####')) : '';
		$body_params["postal_code"] = isset($data_post['billing_postcode']) ? sanitize_text_field($data_post['billing_postcode']) : '';
		$body_params["state"] = isset($data_post['billing_state']) ? sanitize_text_field($data_post['billing_state']) : '';
		$body_params["street"] = isset($data_post['billing_address_1']) ? sanitize_text_field($data_post['billing_address_1']) : '';

		$data_user['exists'] = false; // Até então o usuário não existe, vamos verificar na EasyPayment


		if (isset($data_post['billing_cpf'])) {
			$cpf_cnpj = get_only_numbers($data_post['billing_cpf']);
			$mask_format = (strlen($cpf_cnpj) == 11) ? '###.###.###-##' : '##.###.###/####-##';

			if (in_array(strlen($cpf_cnpj), [11, 14])) {
				$cpf_cnpj = strval(mask($cpf_cnpj, $mask_format));
			}

			$clientes_cadastrados = $this->api->comprador_listar($cpf_cnpj);
			$lista_body = json_decode($clientes_cadastrados['body'], true);

			if (isset($lista_body['objects']) && !empty($lista_body['objects'])) {
				foreach ($lista_body['objects'] as $val) {
					if (get_only_numbers($data_post['billing_cpf']) === get_only_numbers($val['cpf_cnpj'])) {
						$data_user = [
							'id' => $val['id'],
							'cpf_cnpj' => get_only_numbers($val['cpf_cnpj']),
							'exists' => true
						];
						break;
					}
				}
			}
		}

		if ($data_user['exists']) {
			// Atualizar um cliente existente
			$out = $this->api->comprador_atualizar(trim($data_user['id']), json_encode($body_params));
			$client_id = $data_user['id'];
		} else {
			// Criar um novo cliente
			$body_params["cpf_cnpj"] = isset($data_post['billing_cpf']) ? sanitize_text_field($data_post['billing_cpf']) : '';
			$body_params["cpf_cnpj"] = strval($body_params["cpf_cnpj"]);
			$body_params["type"] = (isset($data_post['billing_cpf']) && strlen(get_only_numbers($data_post['billing_cpf'])) == 11) ? 'PF' : 'PJ';

			$out = $this->api->comprador_criar(json_encode($body_params));
			$novo_body = json_decode($out['body'], true);
			$client_id = $novo_body['id'];
		}
		// echo "\$body_params\n";
		return $client_id;

	}

	/**
	 * 
	 * Criar uma cobrança (boleto ou credit), e retorna o ID da cobrança
	 * @link https://sistema.shoppingeasypay.com.br/reference/criando-uma-cobranca-avulsa/
	 * @param array $data_post
	 * @return int
	 */
	public function easypayment_criar_cobranca_avulsa($data_post)
	{
		//print_r($data_post);
		$blog_info = trim(get_bloginfo('name'));
		$order_id = $data_post['store_id_order'];

		$description = $blog_info !== '' ? "Compra realizada em $blog_info, o número dos seu pedido é: #$order_id" : "O número dos seu pedido é: #$order_id";
		$data_post['easypayment_method'] = ($data_post['easypayment_method'] == 'cartao_credito' || $data_post['easypayment_method'] == 'credit_card' || $data_post['easypayment_method'] == 'credit') ? 'credit' : ($data_post['easypayment_method'] == 'boleto' ? 'boleto' : ($data_post['easypayment_method'] == 'pix' ? 'pix' : 'credit'));

		$body_params['customer'] = isset($data_post['easypayment_customer']) ? intval(sanitize_text_field($data_post['easypayment_customer'])) : false;
		$body_params['payment_method'] = isset($data_post['easypayment_method']) ? sanitize_text_field($data_post['easypayment_method']) : '';
		$body_params['due_date'] = date("Y-m-d");
		$body_params['amount'] = strval($data_post['easypayment_cart_total']);
		$body_params['description'] = $description;
		$body_params['payment_type'] = $this->payment_type;

		if (in_array($this->payment_type, $this->payment_type_request)) {
			$body_params['max_installments'] = 12;
		}


		$criar_cobranca = $this->api->cobranca_criar(json_encode($body_params));

		$criar_cobranca_end['body'] = json_decode($criar_cobranca['body'], true);
		unset($criar_cobranca['body']);
		$criar_cobranca_end['request'] = $body_params;
		$criar_cobranca_end['response'] = $criar_cobranca['response'];

		return $criar_cobranca_end;
	}

	public function easypayment_processar_pagamento($data_post)
	{
		$processsar = '';

		$metodo_pagamento = !empty($data_post['IN_POST']['easypayment_method']) ? $data_post['IN_POST']['easypayment_method'] : false;
		// print_r($metodo_pagamento);
		$from_manual = ["pix", "boleto", "billet"];
		if (in_array($metodo_pagamento, $from_manual)) {
			$processsar = $this->api->cobranca_consultar($data_post['body']['id']);

			$responsed['body'] = json_decode($processsar['body'], true);
			$responsed['response'] = $processsar['response'];
			return $responsed;
		} else if (($metodo_pagamento == 'cartao_credito' || $metodo_pagamento == 'credit_card' || $metodo_pagamento == 'credit')) {

			//De fato, cobrar no cartão de crédito
			$body_params['card_number'] = get_only_numbers($data_post['IN_POST']['cartao_credito']['card_number']);
			$body_params['cvv'] = get_only_numbers($data_post['IN_POST']['cartao_credito']['cvv']);
			$body_params['expiration'] = $data_post['IN_POST']['cartao_credito']['expiration'];
			$body_params['holder_cpf_cnpj'] = get_only_numbers($data_post['IN_POST']['cartao_credito']['holder_cpf_cnpj']);
			$body_params['holder_name'] = $data_post['IN_POST']['cartao_credito']['holder_name'];
			$body_params['number_installments'] = get_only_numbers($data_post['IN_POST']['cartao_credito']['number_installments']);

			$processsar = $this->api->cobranca_criar_cartao($data_post['body']['id'], json_encode($body_params)); //enviar para a Pagtech

			// echo "param CARTAO: \n";
			// print_r($body_params);
			$responsed['body'] = json_decode($processsar['body'], true);
			$responsed['request'] = $body_params;
			$responsed['response'] = $processsar['response'];
			// print_r($responsed);
			return $responsed;
		} else if ($metodo_pagamento == 'carne') {

			$body_params['amount'] = strval($data_post['easypayment_cart_total']);
			$body_params['customer'] = $data_post['easypayment_customer'];
			$body_params['description'] = "Pedido: #" . $data_post['store_id_order'];
			$body_params['first_due_date'] = WC_EASYPAYMENT_CARNE_LIMITE;
			$body_params['mode_installments'] = WC_EASYPAYMENT_CARNE_MODE;
			$body_params['number_installments'] = $data_post['carne']['number_installments'];

			$processsar = $this->api->carne_criar(json_encode($body_params));

			$responsed['request'] = $body_params;
			$responsed['response'] = $processsar['response'];
			return $responsed;
			// } else if ($metodo_pagamento == 'pix') {
			// } else if ($metodo_pagamento == 'assinatura') {
		}

		//$processsar = json_decode( $processsar, true );
		return $processsar;
	}

	/**
	 * Process the payment and return the result.
	 *
	 * @param  int $order_id Order ID.
	 * @return array
	 */
	public function process_payment($order_id)
	{
		//if( $_POST['payment_method'] !== 'easypayment') return false;

		$order = wc_get_order($order_id);
		// print_r(json_encode($_POST));
		// Obter o ID do cliente, baseado no CPF (caso não exista, será criado);
		$comprador_id = $this->easypayment_cliente($_POST);
		// 		var_dump($comprador_id);

		// Adiciona o ID do cliente ao $_POST
		$_POST['easypayment_customer'] = $comprador_id;
		$_POST['easypayment_method'] = strval($_POST['easypayment_method']); //boleto|cartao_credito|pix|carne|assinatura

		// ID do pedido, para enviar para a descrição
		$_POST['store_id_order'] = $order_id;
		// print_r(json_encode($_POST));
		// Criar uma cobrança e obtém o ID, válido apenas para Boleto e Cartão de crédito e pix
		$payment_to_create_first = array('boleto', 'cartao_credito', 'credit', 'credit_card', 'pix');
		if (in_array($_POST['easypayment_method'], $payment_to_create_first)) {

			$cobranca_avulsa = $this->easypayment_criar_cobranca_avulsa($_POST); // boleto|credit
			// $paymentMethod = isset($_POST['easypayment_method']) && ($_POST['easypayment_method'] == 'pix' || $_POST['easypayment_method'] == 'cartao_credito' || $_POST['easypayment_method'] == 'credit_card' || $_POST['easypayment_method'] == 'credit') ? 'credit' : $_POST['easypayment_method'];
			$paymentMethod = isset($_POST['easypayment_method']) ? strval($_POST['easypayment_method']) : null;
			$datasInfos = [
				"easypayment_customer_id" => $comprador_id,
				"easypayment_payment_method" => $paymentMethod,
				"wocommerce_order_id" => $order_id
			];
			// print_r($datasInfos);

			if (isset($cobranca_avulsa['response']['code']) && ($cobranca_avulsa['response']['message'] == 'Created' || $cobranca_avulsa['response']['code'] == '201')) {
				//BOLETO OU CARTÃO ENVIADO, BORA RODAR O THANKYOU
				$cobranca_avulsa['IN_POST'] = $_POST;

				$cobranca_process = $this->easypayment_processar_pagamento($cobranca_avulsa); //Cobrar pra valer
				$cobranca_avulsa['cobranca'] = $cobranca_process;
				$cobranca_avulsa['cobranca']['infos'] = $datasInfos;

				$aprove = false;
				$this->cobranca_avulsa = $cobranca_avulsa;

				if (($_POST['easypayment_method'] == 'cartao_credito' || $_POST['easypayment_method'] == 'credit_card' || $_POST['easypayment_method'] == 'credit')) {
					$processar_status = __("Nothing yet", "woocommerce-easypayment");

					$jyra = "init_2";
					if (is_null($cobranca_avulsa['cobranca']) || $cobranca_avulsa['cobranca'] == NULL) {
						$erro_msg = 'EasyPayment: Verifique se os dados do cartão estão corretos';
						wc_add_notice($erro_msg, 'error');
						$processar_status = $erro_msg;
						$aprove = false;
						$jyra = "init_3";
					} else if (isset($cobranca_avulsa['cobranca']['response']['code']) && $cobranca_avulsa['cobranca']['response']['code'] == 500) {
						$this->sendErrosForEmail($cobranca_avulsa['cobranca']);
						$easypayment_code = $cobranca_avulsa['cobranca']['response']['code'];
						$easypayment_msg = $cobranca_avulsa['cobranca']['response']['message'];

						wc_add_notice("EasyPayment [$easypayment_msg]: $easypayment_code.", 'error');
						$processar_status = "EasyPayment [$easypayment_msg]: $easypayment_code - error_NED";
						$aprove = false;
						$jyra = "init_4";
					} else {
						// echo "cobranca AVULSA 5: \n";
						// var_dump( $cobranca_avulsa );
						$processar_status = $this->update_order_status($cobranca_avulsa); //Salva os dados no POST META do Pedido     
						$aprove = true;
						$jyra = "init_5";
					}
				} else if ($_POST['easypayment_method'] == 'boleto') { //Verificação com pagamento via boleto
					$processar_status = $this->update_order_status($cobranca_avulsa); //Salva os dados no POST META do Pedido
					$aprove = true;
					$jyra = "init_6";
				} else if ($_POST['easypayment_method'] == 'pix') { //Verificação com pagamento via pix
					$processar_status = $this->update_order_status($cobranca_avulsa); //Salva os dados no POST META do Pedido
					$aprove = true;
					$jyra = "init_7";
				}
				if ($aprove) {
					WC()->cart->empty_cart(); // Limpar o carrinho
					return array(
						'result' => 'success',
						'redirect' => $order->get_checkout_payment_url(true)
					);
				} else {
					wc_add_notice("EasyPAY [just now]: Falha ao processar o pagamento.", 'error');
				}
			} else if (isset($cobranca_avulsa['response']['code']) && $cobranca_avulsa['response']['code'] == 400) {
				if (isset($cobranca_avulsa['body']['amount'][0])) {
					$cobranca_avulsa['cobranca']['infos'] = $datasInfos;
					$this->sendErrosForEmail($cobranca_avulsa['cobranca']);
					wc_add_notice('EasyPAY: [400 ERROR]' . $cobranca_avulsa['body']['amount'][0], 'error');
				}
			} else if (isset($cobranca_avulsa['response']['code']) && $cobranca_avulsa['response']['code'] == 500) {
				if (isset($cobranca_avulsa['body'])) {
					$cobranca_avulsa['cobranca']['infos'] = $datasInfos;
					$this->sendErrosForEmail($cobranca_avulsa['cobranca']);
					$easypayment_error_500 = json_encode($cobranca_avulsa);
					//  $easypayment_error_500 = array_key_exists('body', $cobranca_avulsa) == true ? json_decode($cobranca_avulsa['body'], true) : 'none';
					//  $easypayment_error_500 = array_key_exists('error_message', $easypayment_error_500) == true ? $easypayment_error_500['error_message'] : 'none';
					wc_add_notice("EasyPAY: [500 server external ]$easypayment_error_500", 'error');
				}
			}
			// 		echo "<pre style='namastê'>";
			// 		print_r($cobranca_avulsa['cobranca']);
			// 		echo "</pre>";
			$this->logger($cobranca_avulsa);
			exit();
		}

		// Processa o pagamento final, conforme a escolha do cliente: carnê ou assinatura
		$payment_to_create_second = array('carne', 'assinatura');
		if (in_array($_POST['easypayment_method'], $payment_to_create_second)) {

			$carne_ou_assinatura = $this->easypayment_processar_pagamento($_POST);
			// 		echo "\n ----- START: Carnê|assinatura ----- \n";
			//         var_dump( $carne_ou_assinatura );
			//         echo "\n ----- END: Carnê|assinatura   ----- \n";
		}
		// 		print_r( json_encode($_POST, JSON_PRETTY_PRINT) );
		//$this->update_order_status( $response );
		// Remove cart.
		//WC()->cart->empty_cart();

		//         foreach ( $response['error'] as $error ) {
		//             wc_add_notice( $error, 'error' );
		//         }


		// 		$use_shipping = isset( $_POST['ship_to_different_address'] ) ? true : false; // WPCS: input var ok, CSRF ok.

		// 		return array(
		// 			'result'   => 'success',
		// 			'redirect' => add_query_arg( array( 'use_shipping' => $use_shipping ), $order->get_checkout_payment_url( true ) ),
		// 		);
	}

	/**
	 * Output for the order received page.
	 * @link https://www.businessbloomer.com/woocommerce-easily-get-order-info-total-items-etc-from-order-object/
	 * @param int $order_id Order ID.
	 */
	public function receipt_page($order_id)
	{

		$simbolo_moeda = get_woocommerce_currency_symbol();
		$order = wc_get_order($order_id);
		$request_data = $_POST;  // WPCS: input var ok, CSRF ok.

		if (isset($_GET['use_shipping']) && true === (bool) $_GET['use_shipping']) {  // WPCS: input var ok, CSRF ok.
			$request_data['ship_to_different_address'] = true;
		}
		// echo "<pre>";
		$meta_generate = get_post_meta($order_id, '_easypayment_order_meta', true);
		// print_r($meta_generate);
		// echo "</pre>";

		// Get and Loop Over Order Items
		$get_formatted_order_total = $order->get_formatted_order_total(); //Total a pagar

		$table_rows = '';
		$table_rows .= '
        <section class="woocommerce-order-details">
            <h2 class="woocommerce-order-details__title">Detalhes do pedido</h2>
            <table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
                <thead>
                    <tr>
                        <th class="woocommerce-table__product-name product-name">Produto</th>
                        <th class="woocomerce-table__product-table product-total">Total</th>
                    </tr>
                </thead>
                <tbody>';

		$frete = $order->get_shipping_total();
		$frete = intval($frete) <= 0 ? "<bdi><span class='woocommerce-Price-currencySymbol'>$simbolo_moeda</span>&nbsp;$frete</bdi" : wc_price($frete);
		foreach ($order->get_items() as $item_id => $item) {
			$product_id = $item->get_product_id();
			$variation_id = $item->get_variation_id();
			$product = $item->get_product();
			$product_name = $item->get_name();
			$quantity = $item->get_quantity();
			$subtotal = $item->get_subtotal();
			$subtotal_formatted = number_format($subtotal, 2, '.', '');
			$total = $item->get_total();
			$tax = $item->get_subtotal_tax();
			$taxclass = $item->get_tax_class();
			$taxstat = $item->get_tax_status();
			$allmeta = $item->get_meta_data();
			$somemeta = $item->get_meta('_whatever', true);
			$product_type = $item->get_type();
			$preco = number_format(($subtotal / $quantity), 2, '.', '');
			$permalink_product = get_permalink($product_id);
			$table_rows .= "
				<tr class='woocommerce-table__line-item order_item'>
					<td class='woocommerce-table__product-name product-name'>
						<a href='$permalink_product'>$product_name</a> <strong class='product-quantity'>×&nbsp;$quantity</strong>
					</td>
					<td class='woocommerce-table__product-total product-total'>
						<span class='woocommerce-Price-amount amount'><bdi><span class='woocommerce-Price-currencySymbol'>$simbolo_moeda</span>&nbsp;$preco</bdi></span>
					</td>
				</tr>";
		}
		$table_rows .= "
            </tbody>
                <tfoot>
                    <tr>
                        <th scope='row'>Subtotal:</th>
                        <td>
                            <span class='woocommerce-Price-amount amount'><span class='woocommerce-Price-currencySymbol'>$simbolo_moeda</span>&nbsp;$subtotal_formatted</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope='row'>Shipping:</th>
                        <td>$frete</td>
                    </tr>
                    <tr>
                        <th scope='row'>Payment method:</th>
                        <td>EasyPAY</td>
                    </tr>
                    <tr>
                        <th scope='row'>Total:</th>
                        <td><span class='woocommerce-Price-amount amount'>$get_formatted_order_total</span></td>
                    </tr>
                </tfoot>
            </table>
        </section>";

		echo $table_rows;

		$easypayment_code = isset($meta_generate['body']['code']) ? $meta_generate['body']['code'] : '';
		$easypayment_code_link = isset($meta_generate['body']['payment_url']) ? $meta_generate['body']['payment_url'] : '#without_link';
		$easypayment_method = isset($meta_generate['IN_POST']['easypayment_method']) ? $meta_generate['IN_POST']['easypayment_method'] : ""; // Tipo de pagamento (credit, boleto, pix)
		$easypayment_qr_image = isset($meta_generate['body']['qr']) ? base64_decode($meta_generate['body']['qr']) : '';

		if (in_array($easypayment_method, ['pix', 'boleto', 'billet'])) {
			if (in_array($easypayment_method, ['boleto', 'billet'])) { ?>
				<div class="" id="easypayment_code" onclick="copyToClipboard('<?php echo $easypayment_code; ?>');">
					<?php echo $easypayment_code; ?>
				</div><?php
			} else if (in_array($easypayment_method, ['pix'])) { ?>
					<div class="text-center">
						<div class="qr"><?php echo $easypayment_qr_image; ?></div>
					</div>
					<div class="fw-bolder">Clique para copiar o seu QRcode</div>
					<div class="">
						<input class="form-control" type="text" readonly value="<?php echo $easypayment_code; ?>"
							onclick="copyToClipboard('<?php echo $easypayment_code; ?>');">
					</div>
				<?php
			} ?>
			<div id="easypayment_code_link">
				<a href="<?php echo $easypayment_code_link; ?>" target="_blank">Ou acess o link direto, clique aqui</a>
			</div>
			<?php
		}

		if (in_array($easypayment_method, ['credit', 'cartao_credito'])) {
			//dados do cartao de crédito
			$error_class = 'error';
			$error_message = 'Error desconhecido ao processar o pagamento.';
			$error_try = '<a class="button cancel" href="' . esc_url($order->get_cancel_order_url()) . '">Tentar novamente</a>';

			if (isset($meta_generate['cobranca']) || $meta_generate['cobranca'] !== NULL) {
				if (isset($meta_generate['cobranca']['body']['status']) && $meta_generate['cobranca']['body']['status'] == WC_EASYPAYMENT_STATUS_FAILED) {
					$error_class = 'error';
					$error_message = 'Falha ao processar o pagamento, ou não foi autorizado';
				}
				echo "
							<div class='easypayment_notice_$error_class'>
								<p>$error_message</p>
							</div>
							\n $error_try";
			}
		}
	}

	/**
	 * IPN handler.
	 */
	public function ipn_handler()
	{
		@ob_clean(); // phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged

		$ipn = $this->api->process_ipn_request($_POST); // WPCS: input var ok, CSRF ok.

		if ($ipn) {
			header('HTTP/1.1 200 OK');
			do_action('valid_easypayment_ipn_request', $ipn);
			exit();
		} else {
			wp_die(esc_html__('EasyPAY Request Unauthorized', 'woocommerce-easypayment'), esc_html__('EasyPAY Request Unauthorized', 'woocommerce-easypayment'), array('response' => 401));
		}
	}

	/**
	 * Save payment meta data.
	 *
	 * @param WC_Order $order Order instance.
	 * @param array    $posted Posted data.
	 */
	protected function save_payment_meta_data($order, $posted)
	{
		if (isset($posted['body']['payment_url'])) {
			$html = file_get_contents($posted['body']['payment_url']);
			$codigo = "";
			$qr = "";

			if (isset($posted['body']['payment_method']) && $posted['body']['payment_method'] == 'pix') {
				if (preg_match('/data-clipboard-text="([^"]+)"/', $html, $matches)) {
					$codigo = $matches[1];
				}
				if (preg_match('/<svg[^>]*>(.*?)<\/svg>/s', $html, $matches)) {
					$qr = $matches[0];
				}
			}

			if (isset($posted['body']['payment_method']) && ($posted['body']['payment_method'] == 'boleto' || $posted['body']['payment_method'] == 'billet')) {
				if (preg_match('/<table[^>]*>.*?<td[^>]*>.*?<span[^>]*>(.*?)<\/span>.*?<\/td>.*?<\/table>/s', $html, $matches)) {
					$codigo = strip_tags($matches[1]);
				}
			}

			$posted['body']['code'] = sanitize_text_field((string) $codigo);
			$posted['body']['qr'] = base64_encode($qr);
		}


		update_post_meta($order->get_id(), '_easypayment_order_meta', $posted);

		$meta_data = array();
		$payment_data = array(
			'type' => '',
			'method' => '',
			'installments' => '',
			'link' => '',
		);
		$fullname['first_name'] = isset($posted['IN_POST']['billing_first_name']) ? sanitize_text_field($posted['IN_POST']['billing_first_name']) : '';
		$fullname['last_name'] = isset($posted['IN_POST']['billing_last_name']) ? sanitize_text_field($posted['IN_POST']['billing_last_name']) : '';
		$full_name = implode(' ', $fullname);

		//Save payment data from body response returned from API
		if (isset($posted['body']) && count($posted['body']) > 0) {
			foreach ($posted['body'] as $key_name => $value) {
				$meta_data[__($key_name)] = sanitize_text_field((string) $value);
			}
		}

		$meta_data['_wc_easypayment_payment_data'] = $payment_data;

		// WooCommerce 3.0 or later.
		if (method_exists($order, 'update_meta_data')) {
			foreach ($meta_data as $key => $value) {
				$order->update_meta_data($key, $value);
			}
			$order->save();
		} else {
			foreach ($meta_data as $key => $value) {
				update_post_meta($order->id, $key, $value);
			}
		}
	}

	/**
	 * Update order status.
	 *
	 * @param array $posted EasyPayment post data.
	 */
	function update_order_status($posted)
	{
		// var_dump( 'ARRAY update_order_status: ', $posted);
		// var_dump( 'OBJECT update_order_status: ',  $this->cobranca_avulsa);
		//var_dump( isset( $posted['IN_POST']['store_id_order'] ) );
		if (isset($posted['IN_POST']['store_id_order'])) {
			//  echo "Bora, funciona!\n";
			$id = (int) str_replace($this->invoice_prefix, '', $posted['IN_POST']['store_id_order']);
			// 			var_dump('update_order_status(ID): ', $id);
			$order = wc_get_order($id);
			// 			echo "O pedido est´´a aqui";
			// var_dump($order);
			// Check if order exists.
			if (!$order) {
				return;
			}

			$order_id = method_exists($order, 'get_id') ? $order->get_id() : $order->id;

			// Checks whether the invoice number matches the order.
			// If true processes the payment.
			if ($order_id === $id) {

				// Save meta data.
				$this->save_payment_meta_data($order, $posted);

				//Processar status do pedido retornado da EasyPayment
				$orderReturnStatus = isset($posted['cobranca']['body']['status']) ? $posted['cobranca']['body']['status'] : 'pending';
				$orderListStatus = $this->status_easypayment;
				// $this->logger($posted);


				// Exemplo
				// 'label'             => 'Em Análise',
				// 'wc_status'         => 'processing',
				// 'wc_create'         => false,
				// 'wc_update_notes'   => "$paymentNamed: O pagamento atualmente está em análise",
				// 'wc_update_status'  => "$paymentNamed: Seu pedido #%s atualmente está em análise/processando",
				// 'wc_stock_update'   => 'decrease',
				// 'wc_send_email'     => true

				if (isset($orderListStatus[$orderReturnStatus]) && (isset($orderReturnStatus) || !empty($orderReturnStatus))) {
					$statusCallback = $orderListStatus[$orderReturnStatus]; //Objetos do status

					$order->update_status($statusCallback['wc_status'], $statusCallback['wc_update_status']);         // Atualizar status
					$order->add_order_note(sprintf($statusCallback['wc_update_notes'], $order->get_order_number()));  // Adicionar notas

					// Adicionar ao stock conforme o status
					if (isset($statusCallback['wc_stock_update']) && $statusCallback['wc_stock_update'] == 'increase') {
						if (function_exists('wc_increase_stock_levels')) {
							wc_increase_stock_levels($order_id);
						}
					}

					// Remover do stock conforme o status                    
					if (isset($statusCallback['wc_stock_update']) && $statusCallback['wc_stock_update'] == 'decrease') {
						if (function_exists('wc_reduce_stock_levels')) {
							wc_reduce_stock_levels($order_id);
						}
					}

					// Opções se o pedido está concluído
					if (isset($orderReturnStatus) && $orderReturnStatus == 'completed') {
					}
				}
			} else {
				if ('yes' === $this->debug) {
					$this->logger($this->id . ' :Error: Order Key does not match with EasyPayment reference.');
				}
			}
		} else {
			return "[" . $this->id . "]: Error on process the ORDER, please consultante our assistence";
		}
	}

	/**
	 * Thank You page message.
	 *
	 * @param int $order_id Order ID.
	 */
	public function thankyou_page($order_id)
	{
		$order = wc_get_order($order_id);
		// WooCommerce 3.0 or later.
		if (method_exists($order, 'get_meta')) {
			$data = $order->get_meta('_wc_easypayment_payment_data');
		} else {
			$data = get_post_meta($order->id, '_wc_easypayment_payment_data', true);
		}

		if (isset($data['type'])) {

			$horse = array(
				'type' => $data['type'],
				'link' => $data['link'],
				'method' => $data['method'],
				'installments' => $data['installments'],
			);
			// 			print_r( 'horse:', $horse );
			wc_get_template(
				'payment-instructions.php',
				$horse,
				'woocommerce/easypayment/',
				WC_EasyPayment::get_templates_path()
			);
		}
	}

	/**
	 * Add content to the WC emails.
	 *
	 * @param  WC_Order $order         Order object.
	 * @param  bool     $sent_to_admin Send to admin.
	 * @param  bool     $plain_text    Plain text or HTML.
	 * @return string
	 */
	public function email_instructions($order, $sent_to_admin, $plain_text = false)
	{
		// WooCommerce 3.0 or later.
		if (method_exists($order, 'get_meta')) {
			if ($sent_to_admin || 'on-hold' !== $order->get_status() || $this->id !== $order->get_payment_method()) {
				return;
			}

			$data = $order->get_meta('_wc_easypayment_payment_data');
		} else {
			if ($sent_to_admin || 'on-hold' !== $order->status || $this->id !== $order->payment_method) {
				return;
			}

			$data = get_post_meta($order->id, '_wc_easypayment_payment_data', true);
		}

		if (isset($data['type'])) {
			if ($plain_text) {
				wc_get_template(
					'emails/plain-instructions.php',
					array(
						'type' => $data['type'],
						'link' => $data['link'],
						'method' => $data['method'],
						'installments' => $data['installments'],
					),
					'woocommerce/easypayment/',
					WC_EasyPayment::get_templates_path()
				);
			} else {
				wc_get_template(
					'emails/html-instructions.php',
					array(
						'type' => $data['type'],
						'link' => $data['link'],
						'method' => $data['method'],
						'installments' => $data['installments'],
					),
					'woocommerce/easypayment/',
					WC_EasyPayment::get_templates_path()
				);
			}
		}
	}

	/**
	 * Get a web file (HTML, XHTML, XML, image, etc.) from a URL.  Return an
	 * array containing the HTTP server response header fields and content.
	 * Source: https://stackoverflow.com/a/14953910/7691346
	 */
	public function get_web_page($url)
	{
		$user_agent = 'Mozilla/5.0 (Windows NT 6.1; rv:8.0) Gecko/20100101 Firefox/8.0';

		$options = array(

			CURLOPT_CUSTOMREQUEST => "GET",         // set request type post or get
			CURLOPT_POST => false,         // set to GET
			CURLOPT_USERAGENT => $user_agent,  // set user agent
			CURLOPT_COOKIEFILE => "cookie.txt",  // set cookie file
			CURLOPT_COOKIEJAR => "cookie.txt",  // set cookie jar
			CURLOPT_RETURNTRANSFER => true,         // return web page
			CURLOPT_HEADER => false,        // don't return headers
			CURLOPT_FOLLOWLOCATION => true,         // follow redirects
			CURLOPT_ENCODING => "",           // handle all encodings
			CURLOPT_AUTOREFERER => true,         // set referer on redirect
			CURLOPT_CONNECTTIMEOUT => 120,          // timeout on connect
			CURLOPT_TIMEOUT => 120,          // timeout on response
			CURLOPT_MAXREDIRS => 10,           // stop after 10 redirects
		);

		$ch = curl_init($url);
		curl_setopt_array($ch, $options);
		$content = curl_exec($ch);
		$err = curl_errno($ch);
		$errmsg = curl_error($ch);
		$header = curl_getinfo($ch);
		curl_close($ch);

		$header['errno'] = $err;
		$header['errmsg'] = $errmsg;
		$header['content'] = $content;
		return $header;
	}
	/**
	 * Registrar LOG do webhook
	 * Source 1: https://www.businessbloomer.com/woocommerce-create-custom-logs/
	 * Source 2: https://developer.woocommerce.com/2017/01/26/improved-logging-in-woocommerce-2-7/
	 */
	public function logger($datas = ['info' => 'Sem dados para mostrar'])
	{
		if (function_exists('wc_get_logger')) {
			$logger = wc_get_logger();
		} else {
			$logger = new WC_Logger();
		}
		$logger->add('EasyPAY', 'Response: ' . print_r($datas, true));
	}
	/**
	 * Send error by email or list email
	 * @param $array $errors
	 * @return send email
	 */
	public function sendErrosForEmail($errors)
	{

		$listEmail = (array) $this->sendErrorsEmailList;
		if (count($listEmail) > 0 && ($this->send_erros_by_email == "on" || $this->send_erros_by_email == "yes")) {
			$to = $listEmail;
			//$responsed = $responsed;
			$fieldsetStyle = "margin-top:10px;background-color: black;color: #8add89;border: 1px none black;border-radius: 4px;";
			$legendStyle = "font-weight:900;background-color: black;border-radius: 5px 5px 0px 0px;padding: 5px 15px;";

			$errors['request']['card_number'] = isset($errors['request']['card_number']) ? $this->showChars($errors['request']['card_number'], "*", -4) : null;
			$errors['request']['cvv'] = isset($errors['request']['cvv']) ? $this->showChars($errors['request']['cvv'], "*", -4) : null;
			$errors['request']['holder_cpf_cnpj'] = isset($errors['request']['holder_cpf_cnpj']) ? $this->showChars($errors['request']['holder_cpf_cnpj'], "*", -3) : null;

			$extasInfos = json_encode($errors['infos'], JSON_PRETTY_PRINT);
			$request = json_encode($errors['request'], JSON_PRETTY_PRINT);

			unset($errors['request']);
			unset($errors['infos']);

			$response = json_encode($errors, JSON_PRETTY_PRINT);
			$subject = sprintf(__("%s [%s]: Error reporting as requested", 'woocommerce-easypayment'), $this->paymentLabel, date("Y-m-d H:i:s"));
			$body = "";
			$body .= sprintf(__("Error processing data on the website: %s", 'woocommerce-easypayment'), $this->siteurl);

			$body .= sprintf(__("<fieldset style='%s'><legend style='%s'>EXTRAS INFOS</legend><pre>%s</pre></fieldset>", 'woocommerce-easypayment'), $fieldsetStyle, $legendStyle, $extasInfos);
			$body .= sprintf(__("<fieldset style='%s'><legend style='%s'>REQUEST</legend><pre>%s</pre></fieldset>", 'woocommerce-easypayment'), $fieldsetStyle, $legendStyle, $request);
			$body .= sprintf(__("<fieldset style='%s'><legend style='%s'>RESPONSE</legend><pre>%s</pre></fieldset>", 'woocommerce-easypayment'), $fieldsetStyle, $legendStyle, $response);

			$headers = array('Content-Type: text/html; charset=UTF-8');

			wp_mail($to, $subject, $body, $headers);
		}
	}
	/**
	 * Paddle in string
	 * 
	 * @param string $string
	 * @param char $charReplace
	 * @param integer $start : is natural number
	 * @example showChars("1234567890", "*", -5), will return : "*****67890"
	 * @example showChars("ABCDEFGHIJKLMN", "#", 5), will return : "ABCDEFGHI#####"
	 * @return string
	 * 
	 */
	public function showChars($string, $charReplace = "#", $start = 0)
	{
		$ch = [];
		for ($v = 0; $v < abs($start); $v++) {
			array_push($ch, $charReplace);
		}
		$chars = implode("", $ch);

		$str_pad_ = $start < 0 ? STR_PAD_LEFT : STR_PAD_RIGHT;
		$end = $start < 0 ? abs($start) : $start;

		$stringMod = substr($string, $start, strlen($string) - $end); // . $chars;
		$string = str_pad($stringMod, (strlen($string)), $chars, $str_pad_);

		return $string;
	}
}


add_action('admin_head', function () { ?>
	<style>
		/** Display nnone add by DanSP; in file: class-wc-easypayment-gateway.php */
		.notice.notice-error {
			display: none;
		}
	</style>
	<?php
});

// add_action( 'woocommerce_thankyou', 'woocommerce_thankyou_change_order_status', 10, 1 );
//  function woocommerce_thankyou_change_order_status( $order_id ){
//     $order = wc_get_order($order_id);
//     $wc_emails = WC()->mailer()->get_emails();
//     if( empty( $wc_emails ) ) return;
//     var_dump($order);
//     $this->generate_submit_form_elements( $order );
// }


/**
 * source: https://github.com/liquidweb/woocommerce-custom-thank-you
 */
// add_action('wp', 'pog_thank_you_page');
function pog_thank_you_page($order_id)
{

	if (isset($_GET['key']) && is_checkout()) {
		get_header();
		wp_enqueue_style('easypayment-checkout', plugins_url('assets/css/frontend/transparent-checkout.css', plugin_dir_path(__FILE__)), array(), WC_EASYPAYMENT_VERSION);

		$url_parse = isset($_SERVER['SCRIPT_URI']) ? parse_url($_SERVER['SCRIPT_URI']) : parse_url(site_url($_SERVER['REQUEST_URI']));
		$url_parse = explode("/", $url_parse['path']);
		// var_dump($url_parse);
		foreach ($url_parse as $clear) {
			if (empty($clear)) {
				unset($clear);
			} else {
				$pa[] = $clear;
			}
		}

		if (end($pa) > 0) {
			$order = new WC_Order(end($pa));
			$id = end($pa);


			$meta_generate = get_post_meta($id, '_easypayment_order_meta', true);

			$_REQUEST['action'] = 'thank_you_page';
			$_REQUEST['order_id'] = isset($id) && $id > 0 ? intval($id) : false;
			$_REQUEST['hash'] = isset($_GET['key']) ? sanitize_text_field($_GET['key']) : false;
			// var_dump($_REQUEST);
			if ($_REQUEST['order_id'] != false && $_REQUEST['hash'] != false) {

				if ($_REQUEST['order_id'] > 0) {
					echo do_shortcode('[woo_order_stub action="' . $_REQUEST['action'] . '" order_id="' . $_REQUEST['order_id'] . '" hash="' . $_REQUEST['hash'] . '"]');
					echo do_shortcode('[woo_order_table action="' . $_REQUEST['action'] . '" order_id="' . $_REQUEST['order_id'] . '" hash="' . $_REQUEST['hash'] . '"]');

					$easypayment_code = isset($meta_generate['body']['code']) ? $meta_generate['body']['code'] : 'ERROR';
					$easypayment_code_clear = preg_replace(' ', '', $easypayment_code);
					$easypayment_code_link = isset($meta_generate['body']['payment_url']) ? $meta_generate['body']['payment_url'] : '#without_link';
					$easypayment_method = isset($meta_generate['IN_POST']['easypayment_method']) ? $meta_generate['IN_POST']['easypayment_method'] : ""; // Tipo de pagamento (credit, boleto, pix)

					if (in_array($easypayment_method, ['pix', 'boleto', 'billet'])) {
						if (in_array($easypayment_method, ['boleto', 'billet'])) { ?>
							<div class="" id="easypayment_code" onclick="copyToClipboard('<?php echo $easypayment_code_clear; ?>');">
								<?php echo $easypayment_code; ?>
							</div><?php
						} else if (in_array($easypayment_method, ['pix'])) { ?>
								<div class="fw-bolder">Clique para copiar o seu QRcode</div>
								<div class="">
									<input class="form-control" type="text" readonly value="<?php echo $easypayment_code; ?>"
										onclick="copyToClipboard('<?php echo $easypayment_code; ?>');">
								</div>
							<?php
						} ?>
						<div id="easypayment_code_link">
							<a href="<?php echo $easypayment_code_link; ?>" target="_blank">Ou acess o link direto, clique aqui</a>
						</div>
						<?php
					}

					if (in_array($easypayment_method, ['credit', 'cartao_credito'])) {
						$error_class = 'error';
						$error_message = 'Error desconhecido ao processar o pagamento.';
						$error_try = '<a class="button cancel" href="' . esc_url($order->get_cancel_order_url()) . '">Tentar novamente</a>';

						if (isset($meta_generate['cobranca']) || $meta_generate['cobranca'] !== NULL) {
							if (isset($meta_generate['cobranca']['body']['status']) && $meta_generate['cobranca']['body']['status'] == WC_EASYPAYMENT_STATUS_FAILED) {
								$error_class = 'error';
								$error_message = 'Falha ao processar o pagamento, ou não foi autorizado';
							}
							echo "
							<div class='easypayment_notice_$error_class'>
								<p>$error_message</p>
							</div>
							\n $error_try";
						}
					}
				}
			}
		} else {
			echo "Erro ao processar o pedido;";
		}
		get_footer();
		// die();
	}
}
