console.log("checkout-transparent.js::init");

function checkCPF() {
  var strCPF = jQuery(".format-cpf").val();
  var Soma;
  var Resto;
  Soma = 0;
  var strCPF = strCPF.replaceAll(".", "").replaceAll("-", "");
  if (strCPF == "00000000000") {
    jQuery(".format-cpf").addClass("is-invalid");
    return;
  }
  for (i = 1; i <= 9; i++) {
    Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (11 - i);
  }
  Resto = (Soma * 10) % 11;

  if (Resto == 10 || Resto == 11) {
    Resto = 0;
  }

  if (Resto != parseInt(strCPF.substring(9, 10))) {
    jQuery(".format-cpf").addClass("is-invalid");
    return;
  }

  Soma = 0;
  for (i = 1; i <= 10; i++)
    Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (12 - i);
  Resto = (Soma * 10) % 11;

  if (Resto == 10 || Resto == 11) {
    Resto = 0;
  }

  if (Resto != parseInt(strCPF.substring(10, 11))) {
    jQuery(".format-cpf").addClass("is-invalid");
    return false;
  } else {
    jQuery(".format-cpf").addClass("is-valid");
    jQuery(".format-cpf").removeClass("is-invalid");
    return true;
  }
}

/**
 * Verifica se uma URL é válida
 * @param {string} URL
 * @return bool
 */
function isValidHttpUrl(string) {
  let url;

  try {
    url = new URL(string);
  } catch (_) {
    return false;
  }

  return url.protocol === "http:" || url.protocol === "https:";
}

function verifiyTypePaymentAndFunctions() {
  var EPselectedMethod = jQuery(
    "#easypayment-payment-form [name=easypayment_method]"
  ).val();
  if (EPselectedMethod == "cartao_credito") {
    var cardFields = [];
    cardFields.push(
      jQuery('[name="cartao_credito[card_number]"]').val() || false
    );
    cardFields.push(
      jQuery('[name="cartao_credito[expiration]"]').val() || false
    );
    cardFields.push(jQuery('[name="cartao_credito[cvv]"]').val() || false);
    cardFields.push(
      jQuery('[name="cartao_credito[holder_name]"]').val() || false
    );
    cardFields.push(
      jQuery('[name="cartao_credito[holder_cpf_cnpj]"]').val() || false
    );
    cardFields.push(
      jQuery('[name="cartao_credito[number_installments]"]').val() || false
    );

    if (cardFields.includes(false) || checkCPF() === false) {
      document
        .querySelector("#place_order")
        .setAttribute("disabled", "disabled");
    } else {
      document.querySelector("#place_order").removeAttribute("disabled");
    }
  } else if (EPselectedMethod == "boleto" || EPselectedMethod == "carne") {
    document.querySelector("#place_order").removeAttribute("disabled");
  }
}

/**
 * Copiar conteúdo para o Clipboard
 * Source: https://jsfiddle.net/pmtxfj30/
 */
function copyToClipboard(text) {
  var sampleTextarea = document.createElement("textarea");
  document.body.appendChild(sampleTextarea);
  sampleTextarea.value = text;
  sampleTextarea.select();
  document.execCommand("copy");
  document.body.removeChild(sampleTextarea);
  alert("Copiado com sucesso");
}

/**
 * Extrair parcelas do pediddo
 * @param {string} url : url do checkout com token para obter a lista de parcelas
 * @return undefined
 */
function parcelasEasypayment(url) {
  var checkURL = isValidHttpUrl(url);
  if (checkURL) {
    fetch(url)
      .then(function (response) {
        return response.text();
      })
      .then(function (data) {
        var tokenEasypayment = document.createElement("DIV");
        tokenEasypayment.id = "getInstallments";
        tokenEasypayment.style = "display: none";
        tokenEasypayment.innerHTML = data;
        document.body.appendChild(tokenEasypayment);
        var installmentsEasypayment = document.querySelectorAll(
          "#getInstallments #id_number_installments option"
        );
        document.querySelector("#getInstallments").remove();

        var injectarParcela = [];
        installmentsEasypayment.forEach((parcelaTexto, parcela) => {
          injectarParcela.push(parcelaTexto.outerHTML);
        });
        var ondeInjetarPArcelas =
          '[name="cartao_credito[number_installments]"]';
        document.querySelector(ondeInjetarPArcelas).innerHTML = "";
        document.querySelector(ondeInjetarPArcelas).innerHTML =
          injectarParcela.join("\n");
      })
      .catch(function (err) {
        console.warn("Error on process parcels", err);
      });
  }
}

// Marcar ou desmarcar RADIO do tipo de pagamento
jQuery(document).ready(function () {
  jQuery(document).on("click", ".nav-link", function () {
    const target = jQuery(this).data("bs-target");
    jQuery(".nav-link").removeClass("active");
    jQuery(this).addClass("active");
    jQuery(".tab-pane").removeClass("show active");
    jQuery(target).addClass("show active");
    jQuery('input[name="easypayment_method"]').prop("checked", false);
    jQuery(this).find('input[name="easypayment_method"]').prop("checked", true);
  });

  try {
    jQuery().mask();
  } catch (err) {
    console.error("Easypayment: ", err);
  } finally {
    jQuery(document).on("input", ".format-cpf", function () {
      jQuery(".format-cpf").mask("000.000.000-00", { reverse: true });
    });

    jQuery(document).on("input", ".format-cvv", function () {
      jQuery(".format-cvv").mask("0000", { reverse: true });
    });

    jQuery(document).on("input", ".format-expiration", function () {
      jQuery(".format-expiration").mask("00/00", { reverse: true });
    });

    jQuery(document).on("input", ".format-credit-card", function () {
      var input = jQuery(this).val();
      input = input.replace(/\D/g, ""); // Remove todos os caracteres não numéricos
      input = input.replace(/(\d{4})/g, "$1 ").trim(); // Adiciona um espaço após cada 4 dígitos
      jQuery(this).val(input);
    });
  }

  jQuery("#place_order").attr("disabled", "disabled");

  jQuery(document).on(
    "change",
    ".wc_payment_method.payment_method_easypayment",
    verifiyTypePaymentAndFunctions
  );
  jQuery(document).on(
    "click",
    ".wc_payment_method.payment_method_easypayment",
    verifiyTypePaymentAndFunctions
  );
  jQuery(document).on(
    "keyup",
    ".wc_payment_method.payment_method_easypayment",
    verifiyTypePaymentAndFunctions
  );
});
