(function ( $ ) {
	'use strict';

	$( function () {

		/**
		 * Switch transparent checkout options display basead in payment type.
		 *
		 * @param {String} method
		 */
		function EasyPaymentSwitchTCOptions( method ) {
			var fields  = $( '#woocommerce_easypayment_tc_credit' ).closest( '.form-table' ),
				heading = fields.prev( 'h3' );

			console.log( 'foi?' );

			if ( 'transparent' === method ) {
				fields.show();
				heading.show();
			} else {
				fields.hide();
				heading.hide();
			}
		}

		/**
		 * Switch banking ticket message display.
		 *
		 * @param {String} checked
		 */
		function EasyPaymentSwitchOptions( checked ) {
			var fields = $( '#woocommerce_easypayment_tc_ticket_message' ).closest( 'tr' );

			if ( checked ) {
				fields.show();
			} else {
				fields.hide();
			}
		}

		/**
		 * Awitch user data for sandbox and production.
		 *
		 * @param {String} checked
		 */
		function EasyPaymentSwitchUserData( checked ) {
			var email = $( '#woocommerce_easypayment_email' ).closest( 'tr' ),
				token = $( '#woocommerce_easypayment_token' ).closest( 'tr' ),
				sandboxEmail = $( '#woocommerce_easypayment_sandbox_email' ).closest( 'tr' ),
				sandboxToken = $( '#woocommerce_easypayment_sandbox_token' ).closest( 'tr' );

			if ( checked ) {
				email.hide();
				token.hide();
				sandboxEmail.show();
				sandboxToken.show();
			} else {
				email.show();
				token.show();
				sandboxEmail.hide();
				sandboxToken.hide();
			}
		}

		EasyPaymentSwitchTCOptions( $( '#woocommerce_easypayment_method' ).val() );

		$( 'body' ).on( 'change', '#woocommerce_easypayment_method', function () {
			EasyPaymentSwitchTCOptions( $( this ).val() );
		}).change();

		EasyPaymentSwitchOptions( $( '#woocommerce_easypayment_tc_ticket' ).is( ':checked' ) );
		$( 'body' ).on( 'change', '#woocommerce_easypayment_tc_ticket', function () {
			EasyPaymentSwitchOptions( $( this ).is( ':checked' ) );
		});

		EasyPaymentSwitchUserData( $( '#woocommerce_easypayment_sandbox' ).is( ':checked' ) );
		$( 'body' ).on( 'change', '#woocommerce_easypayment_sandbox', function () {
			EasyPaymentSwitchUserData( $( this ).is( ':checked' ) );
		});
	});
	
	
	jQuery(document).on('change', '#woocommerce_easypayment_send_erros_by_email', function(){
    jQuery(this).is(':checked') == true 
        ? jQuery("#woocommerce_easypayment_send_email_erros").closest('tr').show()
        : jQuery("#woocommerce_easypayment_send_email_erros").closest('tr').hide();
    });
    jQuery('body').ready(function(){
            jQuery('#woocommerce_easypayment_send_erros_by_email').is(':checked') == true 
            ? jQuery("#woocommerce_easypayment_send_email_erros").closest('tr').show()
            : jQuery("#woocommerce_easypayment_send_email_erros").closest('tr').hide();
            
            checkIfEmailList2errosOK()
    });
    
    function validateEmailList(raw){
        var emails = raw.split(';')
    
    
        var valid = true;
        var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    
        for (var i = 0; i < emails.length; i++) {
            if( emails[i] === "" || !regex.test(emails[i].replace(/\s/g, ""))){
                valid = false;
            }
        }
        return valid;
    }
    jQuery('body').on('keyup', '#woocommerce_easypayment_send_email_erros', checkIfEmailList2errosOK);
    jQuery('body').on('change', '#woocommerce_easypayment_send_email_erros', checkIfEmailList2errosOK);
    function checkIfEmailList2errosOK(){
        if( jQuery('#woocommerce_easypayment_send_erros_by_email').is(':checked') == true ){
            var emails = jQuery('#woocommerce_easypayment_send_email_erros').val();
            if(validateEmailList(emails)){
                jQuery('#emailList').html('<small style="color:green;font-weight: 700;">Email List: OK</small>');
            } else {
                jQuery('#emailList').html('<small style="color:red;font-weight: 700;">Email List: ERROR</small>');
            }
        }
    }
}( jQuery ));
